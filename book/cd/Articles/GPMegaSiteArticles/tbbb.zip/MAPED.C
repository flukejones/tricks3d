//// INCLUDE

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "allegro.h"


//// DEFINE

#define tilSIZE    32
#define maxLEVS     2
#define maxCOLS   30
#define maxROWS   30
#define maxTILE   144

#define BASE        0
#define MASK        1
#define SW        640
#define SH        480


//// STRUCTURES

typedef struct
{
 unsigned char img;
} tileMAP;


//// GLOBALS

BITMAP *buffer, *button, *scrnshot;
DATAFILE *data;

char map_name[80];
char cmode_BUF[20], GMSHT_BUF[12];

unsigned int FIRST, SELECT1, SELECT2, MODE, SIZE, DONE;

int mapX, mapY;
int c_levs, c_cols, c_rows;
int screenshotNUM = 0;

tileMAP levelMAP[maxLEVS][maxCOLS][maxROWS];


//// FUNCTION PROTOTYPES

void Introdt(void);
void SetVars(void);
void GfxFace(void);
void Keybord(void);
void MouseCl(void);
void Refresh(void);
void DrawMap(int x, int y);
void Menubar(void);
void LoadMap(void);
void SaveMap(void);
void NewMap(void);
void TxtValu(void);
void ShwTile(void);
void Help(void);
void Bout(void);


//// FUNCTIONS

void Introdt(void)
{
 allegro_init();
 set_gfx_mode(GFX_AUTODETECT, SW, SH, 0, 0);
 install_keyboard();
 install_mouse();
 install_timer();

 data = load_datafile("data.dat");

 if (!data)
  {
   allegro_exit();
   exit(1);
  }

 set_pallete(data[0].dat);
 gui_fg_color = makecol (0, 0, 0);
 gui_bg_color = makecol (0xFF, 0xFF, 0xFF);
 gui_mg_color = makecol (0x80, 0x80, 0x80);

 buffer = create_bitmap(SW, SH);
 button = create_bitmap(0, 0);
 clear(buffer);
 clear(button);
 clear(screen);
}

void SetVars(void)
{
 mapX = 0;
 mapY = 0; 
 c_levs = 0;
 c_cols = 0;
 c_rows = 0;
 MODE = 0;
 FIRST = 1;
 SELECT1 = 1;
 SELECT2 = 2;
 sprintf (map_name, "UNTITLED.MAF");
}

void GfxFace(void)
{
 line (button, 0, 0, 99, 0, 3);
 line (button, 0, 1, 0, 13, 3);
 line (button, 1, 13, 99, 13, 9);
 line (button, 99, 1, 99, 99, 9); 

 show_mouse (NULL);
 Refresh ();
 Bout ();
 Help();
 show_mouse (screen);
}

void Keybord(void)
{
 if (keypressed())
  {
   if (key[KEY_1])
    {
     MODE = BASE;
     Refresh();
    }

   if (key[KEY_2])
    {
     MODE = MASK;
     Refresh();
    }

   if (key[KEY_DEL])
    {
     c_levs = MODE;
     c_cols = mapY + (mouse_y/tilSIZE);
     c_rows = mapX + (mouse_x/tilSIZE);

     levelMAP[c_levs][c_cols][c_rows].img = 22;
     show_mouse(NULL);
     Refresh();
     show_mouse(screen);  
    }

   if (key[KEY_F1])
    {
     Help();
    }

   if (key[KEY_RIGHT])
    {
     if (mapX != (maxROWS - 15))
      {
       mapX++;
       Refresh();
       rest(64);
      }
    }

   if (key[KEY_LEFT])
    {
     if (mapX != 0)
      {
       mapX--;
       Refresh();
       rest(64);
      }
    }

   if (key[KEY_UP])
    {
     if (mapY != 0)
      {
       mapY--;
       Refresh();
       rest(64);
      }
    }

   if (key[KEY_DOWN])
    {
     if (mapY != (maxROWS - 15))
      {
       mapY++;
       Refresh();
       rest(64);
      }
    }

   else if (key[KEY_N])
    {
     NewMap();
     Refresh();
    }

   else if (key[KEY_L])
    {
     if (file_select ("Load .MAP Map File", map_name, "MAP") != 0)     
      LoadMap();
     Refresh();
    }

   else if (key[KEY_S])
    {
     if (file_select ("Save .MAP Map File", map_name, "MAP") != 0)
      SaveMap();
     Refresh();
    }

   else if (key[KEY_F12])
    {
     scrnshot = create_bitmap (800, 600);
     sprintf(GMSHT_BUF, "gamsht%d.pcx", screenshotNUM++);
     blit(screen, scrnshot, 0, 0, 0, 0, 800, 600);
     get_palette(data[0].dat);
     save_pcx(GMSHT_BUF, scrnshot, data[0].dat);
     destroy_bitmap(scrnshot);
    }

   else if (key[KEY_ESC])
    {
     DONE = 1;
    }
  }
}

void MouseCl(void)
{
 register int c, d, y, z;

 if (mouse_x < 480 && mouse_y < 480)
  {
   c_levs = MODE;
   c_cols = mapY + (mouse_y/tilSIZE);
   c_rows = mapX + (mouse_x/tilSIZE);

   if (mouse_b & 1)
    {
     levelMAP[c_levs][c_cols][c_rows].img = SELECT1;
     show_mouse(NULL);
     Refresh();
     show_mouse(screen);  
    }

   else if (mouse_b & 2)
    {
     levelMAP[c_levs][c_cols][c_rows].img = SELECT2;
     show_mouse(NULL);
     Refresh();
     show_mouse(screen);  
    }    
  }
 
 else if (mouse_x > 480 && mouse_y > 320 && mouse_y < 384)
  {
   if (mouse_b)
    {
     if (mouse_x > 480 && mouse_y > 320 && mouse_x < 560 && mouse_y < 336)
      {/* new map */
       show_mouse (NULL);
       masked_blit(button, screen, 0, 0, 0, 576, 100, 14);
       show_mouse (screen);
       rest(128);
       NewMap();
       Refresh();
      }

     else if (mouse_x > 560 && mouse_y > 320 && mouse_x < 639 && mouse_y < 336)
      {/* load map */
       show_mouse (NULL);
       masked_blit(button, screen, 0, 0, 100, 576, 100, 14);
       show_mouse (screen);
       rest(128);
       if (file_select ("Load .MAP Map File", map_name, "MAP") != 0)     
        LoadMap();
       Refresh();
      }

     else if (mouse_x > 480 && mouse_y > 336 && mouse_x < 560 && mouse_y < 352)
      {/* save map */
       show_mouse (NULL);
       masked_blit(button, screen, 0, 0, 200, 576, 100, 14);
       show_mouse (screen);
       rest(128);
       if (file_select ("Save .MAP Map File", map_name, "MAP") != 0)     
        SaveMap();
       Refresh();
      }

     else if (mouse_x > 560 && mouse_y > 336 && mouse_x < 639 && mouse_y < 352)
      {/* quit */
       show_mouse (NULL);
       masked_blit(button, screen, 0, 0, 300, 576, 100, 14);
       show_mouse (screen);
       rest(128);
       DONE = 1;
      }

     else if (mouse_x > 480 && mouse_y > 352 && mouse_x < 560 && mouse_y < 368)
      {/* previous mode */
       show_mouse (NULL);
       masked_blit(button, screen, 0, 0, 400, 576, 100, 14);
       show_mouse (screen);
       rest(128);
       if (MODE != 0)
        MODE--;
       FIRST = 1;
       SELECT1 = 1;
       SELECT2 = 2;
       rest(120);
       Refresh();
      }

     else if (mouse_x > 560 && mouse_y > 352 && mouse_x < 639 && mouse_y < 368)
      {/* next mode */
       show_mouse (NULL);
       masked_blit(button, screen, 0, 0, 500, 576, 100, 14);
       show_mouse (screen);
       rest(128);
       if (MODE != 1)
        MODE++;
       FIRST = 1;
       SELECT1 = 1;
       SELECT2 = 2;
       rest(120);
       Refresh();
      }

     else if (mouse_x > 480 && mouse_y > 368 && mouse_x < 560 && mouse_y < 384)
      {/* help */
       show_mouse (NULL);
       masked_blit(button, screen, 0, 0, 600, 576, 100, 14);
       show_mouse (screen);
       rest(128);
       Help();
       Refresh();
      }

     else if (mouse_x > 560 && mouse_y > 368 && mouse_x < 639 && mouse_y < 384)
      {/* bout */
       show_mouse (NULL);
       masked_blit(button, screen, 0, 0, 700, 576, 100, 14);
       show_mouse (screen);
       rest(128);
       Bout();
       Refresh();
      }
    }
  }

 else if (mouse_x > 512 && mouse_y < 320)
  {
   if (mouse_b & 1)
    {
     z = FIRST;
     for (c = 0; c < 320; c += 32)
      {
       for (d = 0; d < 128; d += 32)
        {   
         y = ((c / 32) * 4) + (d / 32) + z;
         if (mouse_x > (512+d) && mouse_x < (544+d) && mouse_y > (0+c) && mouse_y < (32+c))
          SELECT1 = y;
        }
      }
     Refresh();
    }

   else if (mouse_b & 2)
    {
     z = FIRST;
     for (c = 0; c < 320; c += 32)
      {
       for (d = 0; d < 128; d += 32)
        {   
         y = ((c / 32) * 4) + (d / 32) + z;
         if (mouse_x > (512+d) && mouse_x < (544+d) && mouse_y > (0+c) && mouse_y < (32+c))
          SELECT2 = y;
        }
      }
     Refresh();
    }    
  }
}

void LoadMap(void)
{
 FILE *file;
 file = fopen(map_name, "rb");
 if (!file)
  return;
 fread(&levelMAP, sizeof(levelMAP), 1, file);
 fclose(file);
}

void SaveMap(void)
{
 FILE *file;
 file = fopen(map_name, "wb");
 if (!file)
  return;
 fwrite(&levelMAP, sizeof(levelMAP), 1, file);
 fclose(file);
}

void NewMap(void)
{
 register int h, i, j; 

 SetVars();
 
 for (h = 0; h < 2; h++)
  {
   for (i = 0; i < maxCOLS; i++) 
    {
     for (j = 0; j < maxROWS; j++) 
      {
       levelMAP[h][i][j].img = 0;
      }
    }
  }

 for (i = 0; i < maxCOLS; i++) 
  {
   for (j = 0; j < maxROWS; j++) 
    {
     levelMAP[0][i][j].img = ((rand() % 8) + 1);
    }
  }

 clear(buffer); 
}

void Refresh(void)
{
 clear(buffer);
 DrawMap(mapX, mapY);
 Menubar();
 TxtValu();
 show_mouse(NULL);
 blit(buffer, screen, 0, 0, 0, 0, SW, SH);
 show_mouse(screen);
}

void DrawMap(int x, int y)
{
 register int i, j, MX, MY;

 /* assigning map coord for base level*/
 MX = x;
 MY = y;

 /* base level blitting */
 for (i = 0; i < 480; i += 32)
  {
   for (j = 0; j < 480; j += 32)
    {
     if (levelMAP[0][MY][MX].img > 0)
      blit(data[levelMAP[0][MY][MX].img].dat, buffer, 0, 0, j, i, tilSIZE, tilSIZE);
     if (levelMAP[1][MY][MX].img > 0)
      masked_blit(data[levelMAP[1][MY][MX].img].dat, buffer, 0, 0, j, i, tilSIZE, tilSIZE);
     MX++;
    }
   MX = x;
   MY++;
  }
}

void Menubar(void)
{
 /* show tile choices */

 int c, d, y, z;
 
 z = FIRST;
 for (c = 0; c < 320; c += 32)
  {
   for (d = 0; d < 128; d += 32)
    {   
     y = ((c / 32) * 4) + (d / 32) + z;
     blit(data[y].dat, buffer, 0, 0, 512+d, 0+c, 32, 32);
    }
  }

}

void TxtValu(void)
{
 if (MODE == BASE)
  sprintf(cmode_BUF, "MODE: BASE");
 else if (MODE == MASK)
  sprintf(cmode_BUF, "MODE: MASK");

 text_mode (-1);

 textout(buffer, font, "NEW", 504, 324, 255);
 textout(buffer, font, "LOAD", 584, 324, 255);
 textout(buffer, font, "SAVE", 504, 340, 255);
 textout(buffer, font, "QUIT", 584, 340, 255);
 textout(buffer, font, "PREV", 504, 356, 255);
 textout(buffer, font, "NEXT", 584, 356, 255);
 textout(buffer, font, "HELP", 504, 372, 255);
 textout(buffer, font, "ABOUT", 580, 372, 255);
 textout(buffer, font, cmode_BUF, 520, 472, 255); 

 blit(data[SELECT1].dat, buffer, 0, 0, 504, 416, tilSIZE, tilSIZE);
 blit(data[SELECT2].dat, buffer, 0, 0, 584, 416, tilSIZE, tilSIZE);
}

void Help(void)
{
 alert ("Key 1: BASE Mode, Key 2: MASK Mode", "Key N: New Map, Key L: Load Map, Key S: Save Map, Key Q: Quit", "Del: Delete Tile, MouseB1: Place/Select 1st Tile. MouseB2: Place/Select 2nd Tile", "Ok", NULL, KEY_ENTER, NULL);
}

void Bout(void)
{
 alert(".MAP Editor", "The Drag Strip: Tile Based Blacc Book (C) 1998 Dragun", "ALL RIGHTS RESEVED.", "Ok", NULL, KEY_ENTER, NULL);
}


//// MAIN

main()
{
 srand(time(0));
 Introdt();
 NewMap();
 GfxFace();

 while(!DONE)
  {  
   Keybord();
   MouseCl();
  }
 
 unload_datafile(data);
 destroy_bitmap(buffer);
 destroy_bitmap(button);
 destroy_bitmap(scrnshot);
 allegro_exit();
 exit(0);
}