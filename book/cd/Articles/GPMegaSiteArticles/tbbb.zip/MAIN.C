#define _MAIN_C

//// INCLUDE

#include "allegro.h"
#include "engine.h"

//// MAIN

main()
{
 Intro();
 Main_Game_Loop();
 Outro();
}