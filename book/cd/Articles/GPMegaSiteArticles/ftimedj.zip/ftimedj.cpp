// here is djgpp specific code
// compile: gcc -o ftimedj.exe ftimedj.cpp -liostr

#include <iostream.h>
#include <time.h> // has uclock()

uclock_t startuclock;  // we want a start time

void initftime(void) {
  startuclock=uclock();
}
// you would have to start up with initftime() at the beginning of the game.

double ftime(void) {
  // here uclock runs at 1193180hz
  // by dividing by its rate you get accurate seconds

  return (double)(uclock()-startuclock)*1.0/UCLOCKS_PER_SEC;

  // note: I dont recommend dividing by a constant.  I recommend that
  // you multiply but the inverse of a constant.  (speed reasons)
}

// here is just a demo of the added frame times and frame rate.
main() {

  float frametime,framestart,frameend; // the vars really needed
  float first,fps,frametimes=0;

  initftime(); // start timer stuff

  framestart=ftime(); // get the first time
  first=framestart;
  
  // game loop
  do {
    do {
      // get the time till its not equal to start frame time, it should,
      // never loop at the rate of this timer, but if it does then
      // it will cap to the frame rate to the rate of this timer which
      // is 1193180 hz
      frameend=ftime();  // get end of frame time
    } while(frameend==framestart);

    frametime=frameend-framestart; // find differnce to get the frametime
    framestart=frameend; // make the first time be the next time

    // the inverse of frame time is the frame rate
    fps=1.0/frametime; // pretty cool huh

    // other game stuff
    cout<<"fps:"<<fps<<endl;

    frametimes+=frametime;

  } while(frameend-first<1.0f);

  cout<<"totaltime:"<<(frameend-first)<<endl;
  cout<<"frametimes:"<<frametimes<<endl;

  return 0;
}