-----------------------
ScreenBench Version 1.0
By Dominic Filion
-----------------------


ScreenBench is an utility that will test the blit speeds of your machine,
using different blitting techniques. ScreenBench can give you a good idea
of what is the maximum performance you could expect from a given screen
resolution.

ScreenBench, despite its name, wasn't meant to be a benchmark program for
your video card or CPU : the multitasking of Windows can affect numbers.
ScreenBench is normally accurate to -+.1 frame per second. If 2 successive
runs of SceenBench give you different numbers, you can estimate that the
highest number is the most accurate.

Shutdown all other programs before running Screenbench.

ScreenBench requires DirectX 3.0 or later.


How it works
------------

ScreenBench performs 4 tests on your machine : raw hardware blit, raw
software blit, software blit w/double buffering and software blit
w/triple buffering. ScreenBench runs all of these tests in screen
resolutions of 640x480, 800x600 and 1027x768, at 8-bit, 16-bit, 24-bit
and 32-bit color depth.

ScreenBench takes a maximum of two minutes to complete all its tests.


Participing in the ScreenBench survey
-------------------------------------

I am running a survey to see what framerates people get on their machines,
to make a "performance database" to see what kind of performance 
different machines get. If you would like to participate, simply save
the report at the end of the tests (with the button with the floppy on it)
and send it to me at dfilion@homemail.com. 


When ScreenBench completes, it will give you a report; the top of the
report lists information about the machine. 

Don't forget to fill in the missing information before sending in your
copy of the report. You should fill in your CPU type and speed, your system
bus spped, if you know it, the name of your videocard, and whether it's PCI
or AGP.



Have fun!
Dominic,
Armagammon game engine
