/*
 * The Game Programming MegaSite - http://www.perplexed.com/GPMega/
 *		"DirectDraw Fading Mania" - Demo Source
 *				By: Matt Reiferson
 *
 */

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdlib.h>
#include <malloc.h>
#include <ddraw.h>

#define RED(p)		(p >> pRed)						// Extracts Red Component
#define GREEN(p)	((p & mGreen) >> pGreen)	// Extracts Green Component
#define BLUE(p)	(p & mBlue)						// Extracts Blue Component
#define RGB16(r, g, b)	((r << pRed) | (g << pGreen) | b)	// Creates RGB Pixel Value

int						DDInitFullscreen(int width, int height, int bpp, HWND hwnd);
void						DDShutdown(void);
LPDIRECTDRAWSURFACE	DDCreateSurface(int width, int height, int mem_flags);
void						DDFillSurface(LPDIRECTDRAWSURFACE lpdds, WORD color);
WORD*						DDLockSurface(LPDIRECTDRAWSURFACE lpdds, int *lpitch);
HRESULT					DDUnlockSurface(LPDIRECTDRAWSURFACE lpdds);
LPDIRECTDRAWSURFACE	DDLoadBitmap(LPCSTR szBitmap, int dx, int dy);
HRESULT					DDCopyBitmap(LPDIRECTDRAWSURFACE pdds, HBITMAP hbm, int x, int y, int dx, int dy);
void						DDGetRGB16();

// the structure which holds pixel RGB masks
typedef struct _RGBMASK
{
	unsigned long rgbRed; // red component
	unsigned long rgbGreen; // green component
	unsigned long rgbBlue; // blue component
} RGBMASK;

// the structure which holds screen format info (5,6,5 or 5,5,5 and masking)
typedef struct _RGB16
{
	RGBQUAD depth;
	RGBQUAD amount;
	RGBQUAD position;
	RGBMASK mask;
} RGB16;

// The various things the game can be doing
typedef enum _GAMESTATE
{
	FADETO, CROSSFADE, FADEBLACK, NOTHING, INIT
} GAMESTATE;

GAMESTATE Game_State = INIT;
BOOL      bActive;			// is the application active
HWND      m_hWnd;				// Global Main Window Handle
HINSTANCE m_hInstance;		// Global Window Instance Handle

RGB16	rgb16;			// Video Card RGB Information Structure
int	mRed, mGreen,		// Faster values of above structure
		mBlue, pRed,		// Faster values of above structure
		pGreen, pBlue;		// Faster values of above structure

WORD PixelShade[32][65536];

int screen_width,			// width of screen
    screen_height,		// height of screen
    screen_bpp;			// bits per pixel

LPDIRECTDRAW         lpDD         = NULL;  // dd object
LPDIRECTDRAWSURFACE  lpDDSPrimary = NULL;  // dd primary surface
LPDIRECTDRAWSURFACE  lpDDSBack    = NULL;  // dd back surface
LPDIRECTDRAWSURFACE	lpDDS1, lpDDS2;		 // our surfaces
LPDIRECTDRAWSURFACE	lpDDSRef;				 // Reference Surface
LPDIRECTDRAWSURFACE	lpDDSTmp;				 // Temporary Transition Surface
LPDIRECTDRAWSURFACE	lpDDSSrc;				 // Source Surface For A Transition
LPDIRECTDRAWSURFACE	lpDDSDes;				 // Destination Surface For A Transition
DDSURFACEDESC        ddsd;                 // a direct draw surface description struct
DDSCAPS              ddscaps;              // a direct draw surface capabilities struct
HRESULT              ddrval;               // result back from dd calls

/*
 * DDGetRGB16:
 *    Must run this function to fill the RGB16 struct with the information needed to plot a pixel
 *		To call this, you must have rgb16 defined as a global (unless you want to modify this) variable
 *		RGB16 rgb16;
 */
void DDGetRGB16(void)
{
	DDSURFACEDESC   ddsd;       // DirectDraw Surface Description
	BYTE            shiftcount; // Shift Counter

	// get a surface despriction
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_PIXELFORMAT;
	lpDDSPrimary->GetSurfaceDesc(&ddsd);
	// Fill in the masking values for extracting colors
	rgb16.mask.rgbRed = ddsd.ddpfPixelFormat.dwRBitMask;
	rgb16.mask.rgbGreen = ddsd.ddpfPixelFormat.dwGBitMask;
	rgb16.mask.rgbBlue = ddsd.ddpfPixelFormat.dwBBitMask;
	
	// get red surface information
	shiftcount = 0;    
	while(!(ddsd.ddpfPixelFormat.dwRBitMask & 1))
	{
		ddsd.ddpfPixelFormat.dwRBitMask >>= 1;
		shiftcount++;
	}
	rgb16.depth.rgbRed = (BYTE)ddsd.ddpfPixelFormat.dwRBitMask;
	rgb16.position.rgbRed = shiftcount;
	rgb16.amount.rgbRed = (ddsd.ddpfPixelFormat.dwRBitMask == 0x1f) ? 3 : 2;

	// get green surface information
	shiftcount = 0;
	while(!(ddsd.ddpfPixelFormat.dwGBitMask & 1))
	{
		ddsd.ddpfPixelFormat.dwGBitMask >>= 1;
		shiftcount++;
	}
	rgb16.depth.rgbGreen =(BYTE)ddsd.ddpfPixelFormat.dwGBitMask;
	rgb16.position.rgbGreen = shiftcount;
	rgb16.amount.rgbGreen = (ddsd.ddpfPixelFormat.dwGBitMask == 0x1f) ? 3 : 2;

	// get Blue surface information
	shiftcount = 0;
		while(!(ddsd.ddpfPixelFormat.dwBBitMask & 1)) 
	{
	ddsd.ddpfPixelFormat.dwBBitMask >>= 1;
	shiftcount++; 
	}
	rgb16.depth.rgbBlue =(BYTE)ddsd.ddpfPixelFormat.dwBBitMask;
	rgb16.position.rgbBlue = shiftcount;
	rgb16.amount.rgbBlue = (ddsd.ddpfPixelFormat.dwBBitMask == 0x1f) ? 3 : 2;
		// fill in variables so we dont' have to access the structure anymore
	mRed = rgb16.mask.rgbRed;         // Red Mask
	mGreen = rgb16.mask.rgbGreen;     // Green Mask
	mBlue = rgb16.mask.rgbBlue;       // Blue Mask
	pRed = rgb16.position.rgbRed;     // Red Position
	pGreen = rgb16.position.rgbGreen; // Green Position
	pBlue = rgb16.position.rgbBlue;   // Blue Position
}

/*
 * DDInitFullscreen:
 *		Initializes DirectDraw as a fullscreen application
 *
 */
int DDInitFullscreen(int width, int height, int bpp, HWND hwnd)
{
   HRESULT ret;

   // create object and test for error
   if(DirectDrawCreate(NULL, &lpDD, NULL) != DD_OK)
      return(0);

   // set cooperation level to windowed mode normal
   if(lpDD->SetCooperativeLevel(hwnd, DDSCL_FULLSCREEN | DDSCL_EXCLUSIVE) != DD_OK)
      return(0);

   // set the display mode
   if(lpDD->SetDisplayMode(width, height, bpp) != DD_OK)
      return(0);

   // set globals
   screen_height = height;
   screen_width = width;
   screen_bpp = bpp;

   // Create the primary surface
   memset(&ddsd, 0, sizeof(ddsd));
   ddsd.dwSize = sizeof(ddsd);
   ddsd.dwFlags = DDSD_CAPS; 

	// set primary surface capabilities
	ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;

   // create the primary surface
   ret = lpDD->CreateSurface(&ddsd, &lpDDSPrimary, NULL);

   // create an offscreen and system mem back surface
   lpDDSBack = DDCreateSurface(width, height, DDSCAPS_SYSTEMMEMORY);

   // clear out both primary and secondary surfaces
   DDFillSurface(lpDDSPrimary, 0);
   DDFillSurface(lpDDSBack, 0);

	DDGetRGB16();

	return 1;
}

/*
 * DDShutdown:
 *		Shuts down and de-initializes DirectDraw
 *
 */
void DDShutdown(void)
{
   // release the secondary surface
   if(lpDDSBack)
	{
      lpDDSBack->Release();
	   lpDDSBack = NULL;
	}

   // release the primary surface
   if(lpDDSPrimary)
	{
      lpDDSPrimary->Release();
	   lpDDSPrimary = NULL;
	}

   // finally, the main dd object
   if(lpDD)
	{
      lpDD->Release();
	   lpDD = NULL;
	}
}

/*
 * DDCreateSurface:
 *		Creates a DirectDraw surface with the specified parameters
 *
 */
LPDIRECTDRAWSURFACE DDCreateSurface(int width, int height, int mem_flags)
{
   DDSURFACEDESC ddsd;         // working description
   LPDIRECTDRAWSURFACE lpdds;  // temporary surface
    
   // set to access caps, width, and height
   memset(&ddsd,0,sizeof(ddsd));
   ddsd.dwSize  = sizeof(ddsd);
   ddsd.dwFlags = DDSD_CAPS | DDSD_WIDTH | DDSD_HEIGHT;

   // set dimensions of the new bitmap surface
   ddsd.dwWidth  =  width;
   ddsd.dwHeight =  height;

   // set surface to offscreen plain
   ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | mem_flags;

   // create the surface
   if(lpDD->CreateSurface(&ddsd,&lpdds,NULL)!=DD_OK)
      return(NULL);

   // return surface
   return(lpdds);
}

/*
 * DDFillSurface:
 *		Fills a surface with the specified color
 */
void DDFillSurface(LPDIRECTDRAWSURFACE lpdds, WORD color)
{
   DDBLTFX ddbltfx; // this contains the DDBLTFX structure

   // clear out the structure and set the size field 
	memset(&ddbltfx,0,sizeof(ddbltfx));
   ddbltfx.dwSize  = sizeof(ddbltfx);

   // set the dwfillcolor field to the desired color
   ddbltfx.dwFillColor = color; 

   // ready to blt to surface
   lpdds->Blt(NULL,                           // ptr to dest rectangle
              NULL,                           // ptr to source surface, NA            
              NULL,                           // ptr to source rectangle, NA
              DDBLT_COLORFILL | DDBLT_WAIT,   // fill and wait                   
              &ddbltfx);                      // ptr to DDBLTFX structure
}

/*
 * DDLockSurface:
 *		Locks a specified surface
 */
WORD *DDLockSurface(LPDIRECTDRAWSURFACE lpdds, int *lpitch)
{
   // lock the surface
	memset(&ddsd, 0, sizeof(ddsd));
	ddsd.dwSize = sizeof(ddsd);
   lpdds->Lock(NULL, &ddsd, DDLOCK_WAIT | DDLOCK_SURFACEMEMORYPTR, NULL);

   // set the memory pitch
   *lpitch = ddsd.lPitch >> 1;

   // return pointer to surface
   return((WORD *)ddsd.lpSurface);
}

/*
 * DDUnlockSurface:
 *		Unlocks a specified surface
 */
HRESULT DDUnlockSurface(LPDIRECTDRAWSURFACE lpdds)
{
   // unlock the surface memory
   return lpdds->Unlock(NULL);
}

/*
 * DDLoadBitmap:
 *		create a DirectDrawSurface from a bitmap resource.
 */
LPDIRECTDRAWSURFACE DDLoadBitmap(LPCSTR szBitmap, int dx, int dy)
{
   HBITMAP             hbm;
   BITMAP              bm;
   DDSURFACEDESC       ddsd;
   IDirectDrawSurface  *pdds;

	hbm = (HBITMAP)LoadImage(NULL, szBitmap, IMAGE_BITMAP, dx, dy, LR_LOADFROMFILE|LR_CREATEDIBSECTION);

   if(hbm == NULL)
	   return NULL;

   // get size of the bitmap
   GetObject(hbm, sizeof(bm), &bm);      // get size of bitmap

   // create a DirectDrawSurface for this bitmap
   ZeroMemory(&ddsd, sizeof(ddsd));
   ddsd.dwSize = sizeof(ddsd);
   ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT |DDSD_WIDTH;
   ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
   ddsd.dwWidth = bm.bmWidth;
   ddsd.dwHeight = bm.bmHeight;

   if(lpDD->CreateSurface(&ddsd, &pdds, NULL) != DD_OK)
 	   return NULL;

   DDCopyBitmap(pdds, hbm, 0, 0, 0, 0);

   DeleteObject(hbm);

   return pdds;
}

/*
 * DDCopyBitmap:
 *	   draw a bitmap into a DirectDrawSurface
 */
HRESULT DDCopyBitmap(LPDIRECTDRAWSURFACE pdds, HBITMAP hbm, int x, int y, int dx, int dy)
{
   HDC                 hdcImage;
   HDC                 hdc;
   BITMAP              bm;
   DDSURFACEDESC       ddsd;
   HRESULT             hr;

   if(hbm == NULL || pdds == NULL)
	   return E_FAIL;

   // make sure this surface is restored.
   pdds->Restore();

   //  select bitmap into a memoryDC so we can use it.
   hdcImage = CreateCompatibleDC(NULL);
   if(!hdcImage)
	   OutputDebugString("CreateCompatibleDC() Failed!\n");
   SelectObject(hdcImage, hbm);

   // get size of the bitmap
   GetObject(hbm, sizeof(bm), &bm);    // get size of bitmap
   dx = dx == 0 ? bm.bmWidth  : dx;    // use the passed size, unless zero
   dy = dy == 0 ? bm.bmHeight : dy;

   // get size of surface.
   ddsd.dwSize = sizeof(ddsd);
   ddsd.dwFlags = DDSD_HEIGHT | DDSD_WIDTH;
   pdds->GetSurfaceDesc(&ddsd);

   if((hr = pdds->GetDC(&hdc)) == DD_OK)
   {
	   StretchBlt(hdc, 0, 0, ddsd.dwWidth, ddsd.dwHeight, hdcImage, x, y, dx, dy, SRCCOPY);
	   pdds->ReleaseDC(hdc);
   }

   DeleteDC(hdcImage);

   return hr;
}

/*
 * InitPixelShade:
 *    Fills the PixelShade array with precomputed shades of every possible pixel (32 shades)
 */
void InitPixelShade(void)
{
	int i, j;
	int r,g,b;
	int dr,dg,db;
	const double alpha[32] = { 0.0, 0.03, 0.06, 0.09,
										0.13, 0.17, 0.21, 0.24,
										0.27, 0.31, 0.34, 0.37,
										0.41, 0.44, 0.47, 0.49,
										0.51, 0.53, 0.56, 0.59,
										0.63, 0.66, 0.69, 0.73,
										0.76, 0.79, 0.83, 0.87,
										0.91, 0.94, 0.97, 1.0 };
	
	for(i=0;i<32;i++)
	{
		for(j=0;j<65536;j++)
		{
			r = RED(j);
			g = GREEN(j);
			b = BLUE(j);
			dr = (int)(r*alpha[i]);
			dg = (int)(g*alpha[i]);
			db = (int)(b*alpha[i]);
			PixelShade[i][j] = RGB16(dr,dg,db);
		}
	}
}

/*
 * AlphaTransition:
 *    Does an alpha transition from Src -> Des
 */
void AlphaTransition(LPDIRECTDRAWSURFACE Src, LPDIRECTDRAWSURFACE Des)
{	
	long i;							 // index into surfaces
	int alpha;                  // Holds current alpha value
	int dpitch, spitch, tpitch, ppitch; // surface pitch for destination, source, temp surfaces
	WORD *AlphaPTR;              // pointer to the current AlphaMap level (Source)
	WORD *InvAlphaPTR;           // the inverted pointer to the current AlphaMap level (Destination)
	WORD *src, *des, *tmp, *prm;
	WORD *fastsrc, *fastdes, *fasttmp;      // Surface memory pointer for source, destination, and temporary surfaces
	RECT SrcRect, DesRect;      // Source and destination rectangles
	
	// Set source and destination rectangles to the screen size
	SetRect(&SrcRect, 0, 0, 640, 480);
	SetRect(&DesRect, 0, 0, 640, 480);
	
	// Create the three surface we are going to use
	lpDDSTmp = DDCreateSurface(640, 480, DDSCAPS_SYSTEMMEMORY); // The temporary surface
	lpDDSSrc = DDCreateSurface(640, 480, DDSCAPS_SYSTEMMEMORY); // The source surface
	lpDDSDes = DDCreateSurface(640, 480, DDSCAPS_SYSTEMMEMORY); // The destination surface
	
	// Blit the transition surfaces into out newly created source/destination surfaces
	lpDDSSrc->Blt(&DesRect, Src, &SrcRect, DDBLT_WAIT, NULL); // Blit Src->lpDDSSrc
	lpDDSDes->Blt(&DesRect, Des, &SrcRect, DDBLT_WAIT, NULL); // Blit Des->lpDDSDes
	
	// lock all three surfaces temporary, source, and destination
	des = DDLockSurface(lpDDSDes, &dpitch);
	src = DDLockSurface(lpDDSSrc, &spitch);
	tmp = DDLockSurface(lpDDSTmp, &tpitch);
	prm = DDLockSurface(lpDDSPrimary, &ppitch);
	
	// for each alpha level
	for(alpha=31;alpha>=0;alpha--)
	{
		// set AlphaMap pointers to appropriate levels
		AlphaPTR = PixelShade[alpha];
		InvAlphaPTR = PixelShade[31-alpha];
		
		// "reset" the *fast* pointers to the locked surfaces
		fastsrc = src;
		fastdes = des;
		fasttmp = tmp;
		
		// loop through every pixel
		for(i=0;i<307200;i++,fasttmp++,fastsrc++,fastdes++)
		{
			// Set the new pixel value in temporary surface
			*fasttmp = AlphaPTR[*fastsrc] + InvAlphaPTR[*fastdes];
		}
		
		// copy the temp surface to the primary surface
		// (640*480) = 307200 (words) * 2 = 614400 (bytes)
		memcpy(prm, tmp, 614400);
	}
	
	// Unlock our temporary, source, and destination surfaces
	DDUnlockSurface(lpDDSPrimary);
	DDUnlockSurface(lpDDSTmp);
	DDUnlockSurface(lpDDSDes);
	DDUnlockSurface(lpDDSSrc);
	
	// Release our temporary, source, and destination surfaces
	lpDDSTmp->Release();
	lpDDSTmp = NULL;
	lpDDSSrc->Release();
	lpDDSSrc = NULL;
	lpDDSDes->Release();
	lpDDSDes = NULL;
}

/*
 * FadeToSurface:
 *    Fades into a surface from black
 */
void FadeToSurface(LPDIRECTDRAWSURFACE lpDDS)
{
	int c;                 // counter variable
	long i;                // incrementing variable
	WORD *tmp, *ref, *prm;
	WORD *fasttmp, *fastref;       // temporary and destination surface mem pointers
	RECT SrcRect, DesRect; // Source and destination rectangles
	int tpitch, rpitch, ppitch;    // temporary and destination surface pitch
	WORD *shade;
	
	// Set the source and destination rectangles to the size of the screen
	SetRect(&SrcRect, 0, 0, 640, 480);
	SetRect(&DesRect, 0, 0, 640, 480);
	
	// Create the surfaces
	lpDDSTmp = DDCreateSurface(640, 480, DDSCAPS_SYSTEMMEMORY); // the temporary surface
	lpDDSRef = DDCreateSurface(640, 480, DDSCAPS_SYSTEMMEMORY); // the temporary surface
	lpDDSRef->Blt(&DesRect, lpDDS, &SrcRect, DDBLT_WAIT, NULL); // blit the desired surface into our destination surface

	// Lock our surfaces temporary, and destination
	tmp = DDLockSurface(lpDDSTmp, &tpitch);
	prm = DDLockSurface(lpDDSPrimary, &ppitch);
	ref = DDLockSurface(lpDDSRef, &rpitch);

	// This can be changed, but it worx out nice to do 10 iterations
	for(c=1;c<=30;c++)
	{
		// get pointer indexed to the start of the current shade level
		shade = PixelShade[c];
		
		// "reset" our *fast* surface pointers
		fasttmp = tmp;
		fastref = ref;

		// for every pixel on the screen (640*480=307200)
		for(i=0;i<307200;i++,fasttmp++,fastref++)
		{
			// new pixel please.....
			*fasttmp = shade[*fastref];
		}

		// copy the temp surface to the primary surface
		// (640*480) = 307200 (words) * 2 = 614400 (bytes)
	   memcpy(prm, tmp, 614400);
	}

	// unlock the temporary surface and destination surface
	DDUnlockSurface(lpDDSTmp);
	DDUnlockSurface(lpDDSPrimary);
	DDUnlockSurface(lpDDSRef);

	// blit the actual destination surface to the primary surface so we're sure
	// the screen is where it should be
	lpDDSPrimary->Blt(&DesRect, lpDDS, &SrcRect, DDBLT_WAIT, NULL);

	// release the temporary and destination surfaces
	lpDDSTmp->Release();
	lpDDSTmp = NULL;
	lpDDSRef->Release();
	lpDDSRef = NULL;
}

/*
 * FadeToBlack:
 *		Fades a screen to black
 */
void FadeToBlack(void)
{
	RECT SrcRect, DesRect; // Source and Destination Rectangles
	WORD *tmp;             // temporary surface memory pointer
	WORD *ref;
	WORD *prm;
	WORD *fastref, *fasttmp;
	int c, tpitch, rpitch, ppitch;         // incrementing variable, temporary surface pitch
	long i;                // another incrementing variable
	WORD *shade;

	// Set source and destination rectangles to size of screen
	SetRect(&SrcRect, 0, 0, 640, 480);
	SetRect(&DesRect, 0, 0, 640, 480);

	// Create our temporary surface
	lpDDSTmp = DDCreateSurface(640, 480, DDSCAPS_SYSTEMMEMORY);
	lpDDSRef = DDCreateSurface(640, 480, DDSCAPS_SYSTEMMEMORY);

	// Blit our primary surface into our temporary SYSTEM MEMORY surface
	lpDDSRef->Blt(&DesRect, lpDDSPrimary, &SrcRect, DDBLT_WAIT, NULL);

	// Lock our temporary surface
	tmp = DDLockSurface(lpDDSTmp, &tpitch);
	ref = DDLockSurface(lpDDSRef, &rpitch);
	prm = DDLockSurface(lpDDSPrimary, &ppitch);

	for(c=30;c>=1;c--)
	{
		// get a pointer indexed to the start of the current shade level
		shade = PixelShade[c];

		// "reset" our *fast* surface pointers
		fastref = ref;
		fasttmp = tmp;

		// for every pixel on the screen (640*480=307200)
		for(i=0;i<307200;i++,fasttmp++,fastref++)
		{
			// new pixel please....
			*fasttmp = shade[*fastref];
		}

		// copy the temp surface to the primary surface
		// (640*480) = 307200 (words) * 2 = 614400 (bytes)
  		memcpy(prm, tmp, 614400);
	}

	// unlock our temporary surface
	DDUnlockSurface(lpDDSTmp);
	DDUnlockSurface(lpDDSRef);
	DDUnlockSurface(lpDDSPrimary);

	// just to make sure the screen is black when this routine is over, fill it with 0
	DDFillSurface(lpDDSPrimary,0);

	// release our temporary surface
	lpDDSTmp->Release();
	lpDDSTmp = NULL;
	lpDDSRef->Release();
	lpDDSRef = NULL;
}

/*
 * WinProc:
 *    Processes windows messages.
 */
long PASCAL WinProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	// determine which message was sent in order to handle it
	switch(message)
	{
		// the app is being activated
	   case WM_ACTIVATEAPP:
			bActive = wParam; // is it active, TRUE or FALSE?
			break;
		// we've returned, kill the windows cursor
		case WM_SETCURSOR:
			SetCursor(NULL); // kill the windows cursor
			break;
		// it's telling us it's time to go, quit.....
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
	}

	// return to caller
	return DefWindowProc(hWnd, message, wParam, lParam);
}

/*
 * FiniApp:
 *    Cleans up the application, frees memory.
 */
void FiniApp(void)
{
	// Blacken the surfaces of the flipping chain
	// prevents residue gfx showing up after closing
	DDFillSurface(lpDDSPrimary, 0); // Fill the primary surface with black
	DDFillSurface(lpDDSBack, 0);    // Fill the back surface with black

	// shutdown directdraw
   DDShutdown();
}

/*
 * InitApp:
 *    Initializes the application window.
 */
BOOL InitApp(HINSTANCE hInst, int nCmdShow)
{
	WNDCLASS WndClass;
	HWND hWnd;
	char *name = "DirectDraw Fading Mania Demo";

	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	WndClass.lpfnWndProc = WinProc;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hInstance = hInst;
	WndClass.hIcon = LoadIcon(0, IDI_APPLICATION);
	WndClass.hCursor = LoadCursor(0, IDC_ARROW);
	WndClass.hbrBackground = (HBRUSH__ *)GetStockObject(BLACK_BRUSH);
	WndClass.lpszMenuName = 0;
	WndClass.lpszClassName = name;
	RegisterClass(&WndClass);

	// create the window, it's fullscreen mode
	hWnd = CreateWindowEx(
		WS_EX_TOPMOST,
		name,
		name,
		WS_POPUP,
		0,0,
		64,
		48,
		NULL,
		NULL,
		hInst,
		NULL);

	if(!hWnd) return FALSE;

	// initialize global window variables
	m_hWnd		= hWnd;
   m_hInstance	= hInst;

	// Show the Window
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	// Initialize the game
	DDInitFullscreen(640, 480, 16, m_hWnd);

	// Initialize the pixel shade table
	InitPixelShade();

   // Hide the mouse cursor
   ShowCursor(FALSE);

	return TRUE;
}

void LoadGFX(void)
{
	lpDDS1 = DDLoadBitmap("bmp1.bmp", 0, 0);
	lpDDS2 = DDLoadBitmap("bmp2.bmp", 0, 0);
}

void KillGFX(void)
{
	lpDDS1->Release();
	lpDDS1 = NULL;
	lpDDS2->Release();
	lpDDS2 = NULL;
}

/*
 * GameMain:
 *		The main game loop....
 */
void GameMain(void)
{
	switch(Game_State)
	{
   	case NOTHING:
         break;
		// Load stuff FOOL!
		case INIT:
			DDFillSurface(lpDDSPrimary, 0);
			DDFillSurface(lpDDSBack, 0);
			LoadGFX();
			Game_State = FADETO;
			break;
		// We are currently in the FADETO phase
	   case FADETO:
			FadeToSurface(lpDDS1); // fade to surface 1
			Game_State = CROSSFADE; // set Game_State to next phase
		   break;
		// We are currently in the CROSSFADE phase
		case CROSSFADE:
			AlphaTransition(lpDDS1, lpDDS2); // do an alpha transition into next screen
			Game_State = FADEBLACK; // set the Game_State to the next phase
			break;
		// We are currently in the FADEBLACK phase
		case FADEBLACK:
			FadeToBlack(); // do another alphatransition to the next screen
			KillGFX();
			Game_State = NOTHING; // set Game_State to next phase
			PostMessage(m_hWnd, WM_DESTROY,0,0); // Post the destroy window message
			break;
	}
}

/*
 * WinMain:
 *    Contains the message loop.
 */
int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow)
{
	MSG msg;

	// initialize the app
	if(!InitApp(hInst, nCmdShow)) return FALSE;

	// infinite loop
	while(1)
	{
		// peekmessage so as not to interrupt processes
		if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{ 
			// if the message said to quit, get the hell outta here
         if(msg.message == WM_QUIT)
            break;

			// translate and dispatch the message
    		TranslateMessage(&msg);
	   	DispatchMessage(&msg);
		}

		// if there are no messages, update the game
		if(bActive)
		{
         GameMain();
		}
	}

	// shutdown game and release all resources
   FiniApp();

   // return to Windows like this
   return(msg.wParam);
}