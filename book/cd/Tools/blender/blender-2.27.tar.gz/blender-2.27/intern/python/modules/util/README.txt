3D utilities 

  (c) onk, 1998-2001

  A few low level & math utilities for 2D/3D computations as:

    - area.py: solving close packing problems in 2D

    - vect.py: low level / OO like matrix and vector calculation module

    - vectools.py: more vector tools for intersection calculation, etc.

    - tree.py: binary trees (used by the BSPtree module)
