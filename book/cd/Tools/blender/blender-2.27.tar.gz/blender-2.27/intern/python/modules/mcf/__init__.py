#mcf 'vendor' packages

#These packages are free software, provided without warranty or
#guarantee, if you use them, you must agree to use them at your
#own risk.  Please see the file license.txt for full license
#details.
