'''
Simple parsing using mxTextTools

tar -cvf simpleparse.tar --exclude-from=exclude.txt
'''