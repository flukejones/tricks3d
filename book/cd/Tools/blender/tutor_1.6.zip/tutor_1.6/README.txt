Blender Example Files 1.6
May 22, 1999

----------------------cube2sphere.blend----------------

- Example of vertex-key framing

Documentation for this .blend file can be found
in the accompanying cube2sphere.txt file.


----------------------glass.blend----------------------

- Example of using texturing options to simulate glass

You can view the effect first by loading the .blend
and pressing F12 to render. You should see a vase
with glass-like transparency. This effect is achieved
by mapping a "Spherical Blend" texture onto the
Alpha channel of the vase, using only the Z coordinates 
and a "Normal" mapping.

This has the effect of forcing the vase to be transparent
on the faces with normals pointing towards (or away
from) the camera, and to be opaque when the normals point
to the side of the camera.


----------------------halostep.blend-------------------

- Example of volumetric shadows for spotlight halo's

To see the volumetric shadow effect load this .blend
and press F12 to render. You should see "sunbeams"
shooting through the square holes.

To use this effect in your own scenes add a spotlight
and set the "Halo" option in the LampButtons (F4) on.
To enable the volumetric calculation you must also
set the "Halostep" button (also in the LampButtons)
to a non-zero value, and turn "Shadow" rendering on
(DisplayButtons -F10).

The "Halostep" button determines the resolution
of the shadow calculation. A value of 1 gives
very smooth volumetric rays, but also greatly
increases rendering time. Typically a value
of 8 is sufficient.


----------------------loft.blend-----------------------

- Example of lofting surfaces

This .blend file is self-documenting, just load it
in Blender and follow the instructions of the
onscreen text. (If you can't see all the text
zoom out with Ctrl+MiddleMouse Button or Keypad-Minus )


----------------------teapot.blend---------------------

- Example of using environment mapping

This file shows how to use standard environment mapping. 
Loading the file and pressing F12 will first render the 
environment map, then the final image.


To add an environment map select the Object and go to 
the MaterialButtons (F5).
Select the texture channel you would like the
environment map to be applied to, and go to the
TextureButtons (F6).

Select the "EnvMap" texture option, and in the "Ob:" button 
enter the name of the Object. Assuming you have placed
the Object in an environment it can
reflect you should be able to press F12
now and see the results.

Editing EnvMaps is a C-key feature. Rendering EnvMaps is 
enabled in all versions.


----------------------mirror.blend---------------------

- Example of using environment mapping for planar reflection

This file is similar to the teapot.blend example,
except it uses environment mapping to produce
a planar reflection. The environment map is used by
a plane that has the "Wave" effect, to give the
map a rippled appearance, like water.

To properly produce a planar reflection you first need
to establish the location where the Camera would be
if it was flipped about the plane of reflection. You should
place an empty at this location, and rename it something
you can remember.

In the mirror.blend file, if you switch to side view
(NumPad-3), you will see the planar reflection Empty
below the Camera, symetrically placed with regards
to the water plane.

To make the planar reflection follow the instructions
listed for teapot.blend (above) but instead
of entering the name of the reflecting Object,
enter the name of the Empty you placed.

If all has gone well you should be able to render
and see a reasonably accurate reflection.

Editing EnvMaps is a C-key feature. Rendering EnvMaps is 
enabled in all versions.

----------------------room.blend-----------------------
----------------------radio.blend----------------------
----------------------radio2.blend---------------------

- Examples of radiosity setups

Each of these three files contains a different
set of meshes, already setup for the radiosity
calculation.  To perform the calculation, load
one of the files and press the "Collect Meshes"
button, then press the "GO" button. Now the
radiosity calculation will begin.

Note: Radiosity calculations can continue
for a very long time, but it is not necessary
for you to let them finish.  Just press
ESC when you are pleased with the
onscreen results.

Radiosity is a C-key feature.
